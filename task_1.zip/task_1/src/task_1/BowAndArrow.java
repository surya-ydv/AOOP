package task_1;

public class BowAndArrow implements Weapon {
    public void use() {
        System.out.println("Shooting an arrow with a bow!");
    }

    public void display() {
        System.out.println("A Bow and Arrow have been equipped!");
    }
}
