package task_1;

public interface GameElementFactory {
    Weapon createWeapon();
    PowerUp createPowerUp();
}
