package task_1;
public abstract class Enemy {
    public abstract void attack();
    public abstract void display();
}
