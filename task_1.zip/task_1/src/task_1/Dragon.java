package task_1;

public class Dragon extends Enemy {
    public void attack() {
        System.out.println("Dragon breathes fire!");
    }

    public void display() {
        System.out.println("A Dragon has appeared!");
    }
}
