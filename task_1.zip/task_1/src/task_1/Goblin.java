package task_1;

public class Goblin extends Enemy {
    public void attack() {
        System.out.println("Goblin attacks with a club!");
    }

    public void display() {
        System.out.println("A Goblin has appeared!");
    }
}
